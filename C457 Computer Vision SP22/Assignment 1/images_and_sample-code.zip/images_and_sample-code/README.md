# a1

Replace this with your report! 

To help you get started, we've included test images (one with a ground truth file) in test-images. We've also provided sample code in Python and C++
to help you see how to do basic image operations in both languages. You can use either of these languages, or another general purpose language,
as long as you write the image processing and vision routines yourselves.

To run the sample python code, just type:

```
cd python-sample
python ./sample.py
```

To run the sample C++ code, type
```
cd c++-sample
make
./sample
```

